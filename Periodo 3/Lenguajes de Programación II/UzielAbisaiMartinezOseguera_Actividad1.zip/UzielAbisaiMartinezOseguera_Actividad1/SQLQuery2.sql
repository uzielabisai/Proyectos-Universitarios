create database UNI

use UNI

create table Centro_de_trabajo(
Numero_de_centro varchar(10) primary key not null,
Nombre_o_descripcion_del_centro varchar(100) not null,
);

create table Puesto(
Nombre_del_puesto varchar(100) primary key not null,
Descripcion_del_puesto varchar(200) not null,
);

create table Directivo(
Es_directivo bit primary key not null,
Numero_de_centro varchar(10) not null,
Prestacion_de_combustible bit not null,
constraint fk_Numero_de_centro foreign key (Numero_de_centro) references Centro_de_trabajo (Numero_de_centro),
);

create table Empleado(
Numero_de_empleado int primary key not null,
Nombre varchar(100) not null,
Apellido_paterno varchar(100) not null,
Apellido_materno varchar(100) not null,
Fecha_de_nacimiento datetime not null,
RFC varchar(15) not null,
Numero_de_centro varchar(10) not null,
Nombre_del_puesto varchar(100) not null,
Descripcion_del_puesto varchar(200) not null,
Es_directivo bit not null,
constraint fk_Id_de_centro foreign key (Numero_de_centro) references Centro_de_trabajo (Numero_de_centro),
constraint fk_Nombre_del_puesto foreign key (Nombre_del_puesto) references Puesto (Nombre_del_puesto),
constraint fk_Es_directivo foreign key (Es_directivo) references Directivo (Es_directivo),
);

insert into Centro_de_trabajo (Numero_de_centro, Nombre_o_descripcion_del_centro)
values ('0101','UNI Plaza Mercado Nuevo')

insert into Centro_de_trabajo (Numero_de_centro, Nombre_o_descripcion_del_centro)
values ('0102', 'UNI Avenida Reforma')

insert into Centro_de_trabajo (Numero_de_centro, Nombre_o_descripcion_del_centro)
values ('0103', 'UNI Centro Historico')

insert into Centro_de_trabajo (Numero_de_centro, Nombre_o_descripcion_del_centro)
values ('0104', 'UNI Zicatela')

insert into Centro_de_trabajo (Numero_de_centro, Nombre_o_descripcion_del_centro)
values ('0105', 'UNI Angel de la Independencia')

insert into Puesto
values
('Gerente de tienda', 'Gerente que supervisa toda la tienda en general'),
('Gerente de sona', 'Gerente de que supervisa todas las tiendas de la sona'),
('Gerente Regional', 'Gerente que supervisa toda una region en particcular'),
('Colaborador general', 'Empleado multifuncional'),
('Colaborador de sistemas', 'Encargado de supervisar las tecnologias de la empresa')

insert into Directivo
values
('1','0101','1')

insert into Directivo
values
('1', '0102', '1'),
('1', '0103', '0'),
('0', '0104', '0'),
('0', '0105', '1')