#include <iostream>
#include <string>

using namespace std;

class Persona {
	string nombre;
	int edad;

public:

	string getNombre() {
		return nombre;
	}

	void setNombre(string nuevoNombre) {
		nombre = nuevoNombre;
	}

	int getEdad() {
		return edad;
	}

	void setEdad(int nuevaEdad) {
		edad = nuevaEdad;
	}

};

int main() {
	Persona persona;

	string nombreUsuario;
	int edadUsuario;

	cout << "Ingresa su nombre por favor: ";
	cin >> nombreUsuario;

	cout << "Ingresa su edad por favor: ";
	cin >> edadUsuario;

	persona.setNombre(nombreUsuario);
	persona.setEdad(edadUsuario);

	cout << "Nombre establecido: " << persona.getNombre() << endl;
	cout << "Edad establecido: " << persona.getEdad() << endl;

	return 0;
}