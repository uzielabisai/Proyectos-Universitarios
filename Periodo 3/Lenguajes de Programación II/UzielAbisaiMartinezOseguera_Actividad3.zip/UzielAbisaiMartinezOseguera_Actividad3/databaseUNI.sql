create database UNI

use UNI

create table Centro_de_trabajo(
N�mero_de_centro int primary key not null,
Nombre_de_centro varchar(100) not null,
Ciudad varchar(100) not null,
);

create table Puesto(
Descripci�n_del_puesto varchar(200) primary key not null,
Directivo bit not null,
);

create table Empleado(
N�mero_de_empleado int primary key not null,
Nombre varchar(100) not null,
Apellido_paterno varchar(100) not null,
Apellido_materno varchar(100) not null,
Fecha_de_nacimiento datetime not null,
RFC varchar(13) not null,
Nombre_de_centro int not null,
Descripci�n_del_puesto varchar(200) not null,
Es_directivo bit not null,
constraint fk_Nombre_de_centro foreign key (Nombre_de_centro) references Centro_de_trabajo (N�mero_de_centro),
constraint fk_Descripci�n_del_puesto foreign key (Descripci�n_del_puesto) references Puesto (Descripci�n_del_puesto),
);

create table Directivo(
N�mero_de_empleado int primary key not null,
N�mero_del_centro_que_supervisa int not null,
Prestaci�n_de_combustible bit not null,
constraint fk_N�mero_de_empleado foreign key (N�mero_de_empleado) references Empleado (N�mero_de_empleado),
constraint fk_N�mero_del_centro_que_supervisa foreign key (N�mero_del_centro_que_supervisa) references Centro_de_trabajo (N�mero_de_centro),
);

insert into Centro_de_trabajo
values
(100, 'UNI Reforma', 'Cuautla Morelos'),
(101, 'UNI La primavera', 'Oaxaca de Juarez Oaxaca'),
(102, 'UNI Artilleros', 'Cuernavaca Morelos'),
(103, 'UNI YeriMua', 'CDMX'),
(104, 'UNI AMLO', 'CDMX');

insert into Puesto
values
('Gerente de tienda', 1),
('Gerente de sona', 1),
('Gerente regional', 1),
('Asesor de ventas', 0),
('Promotor de marca', 0);

insert into Empleado
values
(1, 'Juan', 'G�mez', 'P�rez', '1990-05-15', 'ABC123456DEF', 100, 'Gerente de tienda', 1),
(2, 'Mar�a', 'L�pez', 'Garc�a', '1995-08-20', 'DEF789012GHI', 101, 'Asesor de ventas', 0),
(3, 'Pedro', 'Mart�nez', 'Gonz�lez', '1988-12-10', 'GHI345678JKL', 102, 'Gerente de sona', 1),
(4, 'Ana', 'Hern�ndez', 'Ruiz', '1992-03-25', 'JKL901234MNO', 103, 'Promotor de marca', 0),
(5, 'Carlos', 'Rodr�guez', 'S�nchez', '1997-11-05', 'MNO567890PQR', 104, 'Gerente regional', 1);

insert into Directivo
values
(1, 100, 1),
(3, 102, 1),
(5, 104, 1);
